import Game from './components/game'; //.js
import React from 'react';
import ReactDOM from 'react-dom';

document.addEventListener("DOMContentLoaded", () => {
    ReactDOM.render(<Game />, document.getElementById('root'));
});