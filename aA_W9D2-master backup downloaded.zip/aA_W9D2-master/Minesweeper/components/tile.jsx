import React from 'react';

export default class Tile extends React.Component{
    constructor(props){
        super(props);

        this.handleClick = this.handleClick.bind(this);
    }
    
    handleClick(e) {
        //check if alt click or regular
        this.props.updateGame(this.props.tile, e.altKey);
    }

    render(){
        const tile = this.props.tile;
        let klass, display, count;
       if (tile.flagged) {
            display = '\u1';
            klass = 'flagged';
        } else if (tile.explored) {
           count = tile.adjacentBombCount();
           if (tile.bombed) {
               display = '\u2620';
               klass = 'bombed';
           } else if (count) {
                display = count;
                klass = 'explored';
            } else {
                display = '';
                klass = 'explored';
            }
        }
        
        return (
            // <div className={'tile ' + klass}>{display}</div>
            <div className={'tile ' + klass} onClick={this.handleClick}>{display}</div>
        );
    }

}