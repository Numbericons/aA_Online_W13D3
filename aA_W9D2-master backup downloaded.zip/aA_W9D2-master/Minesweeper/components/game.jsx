import React from 'react';
import * as Minesweeper from './minesweeper.jsx';
import Board from './board.jsx';


export default class Game extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            board: new Minesweeper.Board(10,24)
        }
        this.updateGame = this.updateGame.bind(this);
        this.restartGame = this.restartGame.bind(this);
    }

    updateGame(tile, isAltKey){
        if (isAltKey) {
            tile.toggleFlag();
        } else {
            tile.explore();
        }
        this.setState({ board: this.state.board })
    }

    restartGame() {
        this.state = {
            board: new Minesweeper.Board(10, 24)
        }
    }

    render() {
        let result =  ''; 
        //this.state.board.lost();
        let modal;
        if(this.state.board.lost()) {
            // result = 'YOU LOSE! :(';
            modal = <div className='modal-screen'>
                <form className="modal-form">
                    <span>YOU LOSE! :(</span>
                    <br/>
                   <button onClick={this.restartGame}> Restart Game? </button>
                </form>
            </div>
        } else if (this.state.board.won()) {
            // result = 'YOU WON THE GAME! xD';;
            modal = <div className='modal-screen'>
                <form className="modal-form">
                    <span>YOU WON THE GAME! xD</span>
                    <br/>
                    <button onClick={this.restartGame}> Restart Game? </button>
                </form>
            </div>
        }
        

        return(
            <div>
                <Board board={this.state.board} updateGame={this.updateGame}/>
                {modal}
            </div>
        );
    }
}