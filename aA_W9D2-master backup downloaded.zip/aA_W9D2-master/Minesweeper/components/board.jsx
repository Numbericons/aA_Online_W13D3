import React from 'react';
import Tile from './tile.jsx';

export default class Board extends React.Component {
    constructor(props){
        super(props);
        this.renderRows = this.renderRows.bind(this);
        this.renderTiles = this.renderTiles.bind(this);
    }
    
    renderRows() {
        const board = this.props.board;
        return board.grid.map((row, i) =>{
            return (
                <div className='row' key={i}>
                    {this.renderTiles(row,i)}
                </div>
            );
        });
    }

    renderTiles(row, i) {
        return row.map((pos,j) =>{
            return (
                <Tile 
                    tile={pos}
                    updateGame= {this.props.updateGame}
                    key={[i,j]}
                />
            );
        })
    }

    render() {
        // const board = this.props.board;

        // const tiles = board.grid.map ((row, i) =>{
        //     
        //     return row.map((tile, j) => {
        //        return <Tile
        //             tile={tile} //col
        //             updategame= {this.props.updateGame}
        //             key={j} // {rowi,tilej}
        //         />
        //     })
        // });
        // const rows = [];
        
        // board.grid.forEach((row, rowi) =>{
        //     let currentRow = [];
        //     row.forEach((tile, tilei) =>{
        //         currentRow.push(<Tile 
        //             tile={tile}
        //             updateGame={this.props.updateGame}
        //             key={[rowi,tilei]}
        //         />);
        //     });
        //     rows.push(currentRow);
        // });
        // debugger;
        return (
            <div className='board'>
                {this.renderRows()}
            </div>
        )
    }
}

// this.state.items.map(item => (<li>{item}</li>))